package kingim.vo;

public class UploadFile {
	private int code;
	private String msg;
	private UFile data;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public UFile getData() {
		return data;
	}

	public void setData(UFile data) {
		this.data = data;
	}

}
