package kingim.dao;

import kingim.model.Group;
import tk.mybatis.mapper.common.Mapper;

public interface GroupMapper extends Mapper<Group> {
	
}