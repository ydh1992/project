package kingim.dao;

import kingim.model.GroupUser;
import tk.mybatis.mapper.common.Mapper;

public interface GroupUserMapper extends Mapper<GroupUser> {
	
}