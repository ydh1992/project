package kingim.dao;

import kingim.model.Friend;
import tk.mybatis.mapper.common.Mapper;

public interface FriendMapper extends Mapper<Friend> {
	
}