package com.qiqiim.webserver.user.model;


public class ImGroupUserData {
	public Long id;//分组ID
	public String groupname;//分组Name
	public String avatar;//
	public String members;//分组用户数 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getMembers() {
		return members;
	}
	public void setMembers(String members) {
		this.members = members;
	}
	 
	
}
